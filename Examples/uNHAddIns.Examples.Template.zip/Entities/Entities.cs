﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NH
{
    public class Foo
    {
        private int id;

        public virtual int Id
        {
            get { return id; }
            set { id = value; }
        }
        private string name;

        public virtual string Name
        {
            get { return name; }
            set { name = value; }
        }
        private string misc;

        public virtual string Misc
        {
            get { return misc; }
            set { misc = value; }
        }
    
    }

    public class OtherFoo
    {
        private int id;

        public virtual int Id
        {
            get { return id; }
            set { id = value; }
        }

        private string name;

        public virtual string Name
        {
            get { return name; }
            set { name = value; }
        }

        private string misc;

        public virtual string Misc
        {
            get { return misc; }
            set { misc = value; }
        }   
    }

    


}
