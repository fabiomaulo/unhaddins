using System;
using System.Collections;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Tool.hbm2ddl;
using System.Diagnostics;

namespace NH
{
	class Program
	{
		public static void Main()
		{
			Configuration cfg = new Configuration();
			cfg.Configure("hibernate.cfg.xml");
			SchemaExport exporter = new SchemaExport(cfg);
			exporter.Create(true, true);

			using (ISessionFactory sf = cfg.BuildSessionFactory())
			{				
				using (ISession session = sf.OpenSession())
				{
					Foo f1 = new Foo();					

					f1.Misc = "m1";
					f1.Name = "n1";		
					
					session.Save(f1);
					
					session.Flush();
					
					Debug.Assert(session.CreateCriteria(typeof(Foo)).List().Count == 1);
				}
				
			}
			Console.WriteLine("Done");
			Console.ReadKey(true);
		}
	}
}
