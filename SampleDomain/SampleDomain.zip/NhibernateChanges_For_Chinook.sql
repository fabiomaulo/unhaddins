--
-- Script To Update dbo.Artist Table In .\sqlexpress.Chinook_ORIGINAL
-- Generated jueves, julio 23, 2009, at 05:28 PM
--
-- Please backup .\sqlexpress.Chinook_ORIGINAL before executing this script
--


BEGIN TRANSACTION
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

PRINT 'Updating dbo.Artist Table'
GO

SET ANSI_NULLS, ANSI_PADDING, ANSI_WARNINGS, ARITHABORT, QUOTED_IDENTIFIER, CONCAT_NULL_YIELDS_NULL ON
GO

SET NUMERIC_ROUNDABORT OFF
GO


IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__Album__ArtistId__108B795B')
      ALTER TABLE [dbo].[Album] DROP CONSTRAINT [FK__Album__ArtistId__108B795B]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   CREATE TABLE [dbo].[tmp_Artist] (
   [ArtistId] [int] NOT NULL,
   [Name] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL
)
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   INSERT INTO [dbo].[tmp_Artist] ([ArtistId], [Name])
   SELECT [ArtistId], [Name]
   FROM [dbo].[Artist]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   DROP TABLE [dbo].[Artist]
GO

sp_rename N'[dbo].[tmp_Artist]', N'Artist'

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   ALTER TABLE [dbo].[Artist] ADD CONSTRAINT [PK__Artist__08EA5793] PRIMARY KEY CLUSTERED ([ArtistId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
BEGIN
   PRINT 'dbo.Artist Table Updated Successfully'
   COMMIT TRANSACTION
END ELSE
BEGIN
   PRINT 'Failed To Update dbo.Artist Table'
END
GO


--
-- Script To Update dbo.Album Table In .\sqlexpress.Chinook_ORIGINAL
-- Generated jueves, julio 23, 2009, at 05:28 PM
--
-- Please backup .\sqlexpress.Chinook_ORIGINAL before executing this script
--


BEGIN TRANSACTION
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

PRINT 'Updating dbo.Album Table'
GO

SET ANSI_NULLS, ANSI_PADDING, ANSI_WARNINGS, ARITHABORT, QUOTED_IDENTIFIER, CONCAT_NULL_YIELDS_NULL ON
GO

SET NUMERIC_ROUNDABORT OFF
GO


IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__Track__AlbumId__117F9D94')
      ALTER TABLE [dbo].[Track] DROP CONSTRAINT [FK__Track__AlbumId__117F9D94]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__Album__ArtistId__108B795B')
      ALTER TABLE [dbo].[Album] DROP CONSTRAINT [FK__Album__ArtistId__108B795B]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   CREATE TABLE [dbo].[tmp_Album] (
   [AlbumId] [int] NOT NULL,
   [Title] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL,
   [ArtistId] [int] NULL
)
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   INSERT INTO [dbo].[tmp_Album] ([AlbumId], [Title], [ArtistId])
   SELECT [AlbumId], [Title], [ArtistId]
   FROM [dbo].[Album]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   DROP TABLE [dbo].[Album]
GO

sp_rename N'[dbo].[tmp_Album]', N'Album'

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   ALTER TABLE [dbo].[Album] ADD CONSTRAINT [PK__Album__0425A276] PRIMARY KEY CLUSTERED ([AlbumId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
BEGIN
   PRINT 'dbo.Album Table Updated Successfully'
   COMMIT TRANSACTION
END ELSE
BEGIN
   PRINT 'Failed To Update dbo.Album Table'
END
GO


--
-- Script To Update dbo.Employee Table In .\sqlexpress.Chinook_ORIGINAL
-- Generated jueves, julio 23, 2009, at 05:28 PM
--
-- Please backup .\sqlexpress.Chinook_ORIGINAL before executing this script
--


BEGIN TRANSACTION
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

PRINT 'Updating dbo.Employee Table'
GO

SET ANSI_NULLS, ANSI_PADDING, ANSI_WARNINGS, ARITHABORT, QUOTED_IDENTIFIER, CONCAT_NULL_YIELDS_NULL ON
GO

SET NUMERIC_ROUNDABORT OFF
GO


IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__Customer__Suppor__15502E78')
      ALTER TABLE [dbo].[Customer] DROP CONSTRAINT [FK__Customer__Suppor__15502E78]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__Employee__Report__145C0A3F')
      ALTER TABLE [dbo].[Employee] DROP CONSTRAINT [FK__Employee__Report__145C0A3F]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__Employee__Report__145C0A3F')
      ALTER TABLE [dbo].[Employee] DROP CONSTRAINT [FK__Employee__Report__145C0A3F]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   CREATE TABLE [dbo].[tmp_Employee] (
   [EmployeeId] [int] NOT NULL,
   [LastName] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL,
   [FirstName] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL,
   [Title] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL,
   [BirthDate] [datetime] NULL,
   [HireDate] [datetime] NULL,
   [Address] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL,
   [City] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL,
   [State] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL,
   [Country] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL,
   [PostalCode] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL,
   [Phone] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL,
   [Fax] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL,
   [Email] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL,
   [ReportsTo] [int] NULL
)
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   INSERT INTO [dbo].[tmp_Employee] ([EmployeeId], [LastName], [FirstName], [Title], [BirthDate], [HireDate], [Address], [City], [State], [Country], [PostalCode], [Phone], [Fax], [Email], [ReportsTo])
   SELECT [EmployeeId], [LastName], [FirstName], [Title], [BirthDate], [HireDate], [Address], [City], [State], [Country], [PostalCode], [Phone], [Fax], [Email], [ReportsTo]
   FROM [dbo].[Employee]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   DROP TABLE [dbo].[Employee]
GO

sp_rename N'[dbo].[tmp_Employee]', N'Employee'

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   ALTER TABLE [dbo].[Employee] ADD CONSTRAINT [PK__Employee__00551192] PRIMARY KEY CLUSTERED ([EmployeeId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
BEGIN
   PRINT 'dbo.Employee Table Updated Successfully'
   COMMIT TRANSACTION
END ELSE
BEGIN
   PRINT 'Failed To Update dbo.Employee Table'
END
GO


--
-- Script To Update dbo.Customer Table In .\sqlexpress.Chinook_ORIGINAL
-- Generated jueves, julio 23, 2009, at 05:28 PM
--
-- Please backup .\sqlexpress.Chinook_ORIGINAL before executing this script
--


BEGIN TRANSACTION
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

PRINT 'Updating dbo.Customer Table'
GO

SET ANSI_NULLS, ANSI_PADDING, ANSI_WARNINGS, ARITHABORT, QUOTED_IDENTIFIER, CONCAT_NULL_YIELDS_NULL ON
GO

SET NUMERIC_ROUNDABORT OFF
GO


IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__Invoice__Custome__164452B1')
      ALTER TABLE [dbo].[Invoice] DROP CONSTRAINT [FK__Invoice__Custome__164452B1]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__Customer__Suppor__15502E78')
      ALTER TABLE [dbo].[Customer] DROP CONSTRAINT [FK__Customer__Suppor__15502E78]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   CREATE TABLE [dbo].[tmp_Customer] (
   [CustomerId] [int] NOT NULL,
   [FirstName] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL,
   [LastName] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL,
   [Company] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL,
   [Address] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL,
   [City] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL,
   [State] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL,
   [Country] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL,
   [PostalCode] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL,
   [Phone] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL,
   [Fax] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL,
   [Email] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL,
   [SupportRepId] [int] NULL
)
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   INSERT INTO [dbo].[tmp_Customer] ([CustomerId], [FirstName], [LastName], [Company], [Address], [City], [State], [Country], [PostalCode], [Phone], [Fax], [Email], [SupportRepId])
   SELECT [CustomerId], [FirstName], [LastName], [Company], [Address], [City], [State], [Country], [PostalCode], [Phone], [Fax], [Email], [SupportRepId]
   FROM [dbo].[Customer]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   DROP TABLE [dbo].[Customer]
GO

sp_rename N'[dbo].[tmp_Customer]', N'Customer'

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   ALTER TABLE [dbo].[Customer] ADD CONSTRAINT [PK__Customer__0CBAE877] PRIMARY KEY CLUSTERED ([CustomerId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
BEGIN
   PRINT 'dbo.Customer Table Updated Successfully'
   COMMIT TRANSACTION
END ELSE
BEGIN
   PRINT 'Failed To Update dbo.Customer Table'
END
GO


--
-- Script To Update dbo.Genre Table In .\sqlexpress.Chinook_ORIGINAL
-- Generated jueves, julio 23, 2009, at 05:28 PM
--
-- Please backup .\sqlexpress.Chinook_ORIGINAL before executing this script
--


BEGIN TRANSACTION
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

PRINT 'Updating dbo.Genre Table'
GO

SET ANSI_NULLS, ANSI_PADDING, ANSI_WARNINGS, ARITHABORT, QUOTED_IDENTIFIER, CONCAT_NULL_YIELDS_NULL ON
GO

SET NUMERIC_ROUNDABORT OFF
GO


IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__Track__GenreId__1367E606')
      ALTER TABLE [dbo].[Track] DROP CONSTRAINT [FK__Track__GenreId__1367E606]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   CREATE TABLE [dbo].[tmp_Genre] (
   [GenreId] [int] NOT NULL,
   [Name] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL
)
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   INSERT INTO [dbo].[tmp_Genre] ([GenreId], [Name])
   SELECT [GenreId], [Name]
   FROM [dbo].[Genre]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   DROP TABLE [dbo].[Genre]
GO

sp_rename N'[dbo].[tmp_Genre]', N'Genre'

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   ALTER TABLE [dbo].[Genre] ADD CONSTRAINT [PK__Genre__7E6CC920] PRIMARY KEY CLUSTERED ([GenreId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
BEGIN
   PRINT 'dbo.Genre Table Updated Successfully'
   COMMIT TRANSACTION
END ELSE
BEGIN
   PRINT 'Failed To Update dbo.Genre Table'
END
GO


--
-- Script To Create dbo.hibernate_unique_key Table In .\sqlexpress.Chinook_ORIGINAL
-- Generated jueves, julio 23, 2009, at 05:28 PM
--
-- Please backup .\sqlexpress.Chinook_ORIGINAL before executing this script
--


BEGIN TRANSACTION
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

PRINT 'Creating dbo.hibernate_unique_key Table'
GO

SET ANSI_NULLS, ANSI_PADDING, ANSI_WARNINGS, ARITHABORT, QUOTED_IDENTIFIER, CONCAT_NULL_YIELDS_NULL ON
GO

SET NUMERIC_ROUNDABORT OFF
GO

CREATE TABLE [dbo].[hibernate_unique_key] (
   [next_hi] [int] NULL
)
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
BEGIN
   PRINT 'dbo.hibernate_unique_key Table Added Successfully'
   COMMIT TRANSACTION
END ELSE
BEGIN
   PRINT 'Failed To Add dbo.hibernate_unique_key Table'
END
GO

--
-- Script To Update dbo.Invoice Table In .\sqlexpress.Chinook_ORIGINAL
-- Generated jueves, julio 23, 2009, at 05:28 PM
--
-- Please backup .\sqlexpress.Chinook_ORIGINAL before executing this script
--


BEGIN TRANSACTION
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

PRINT 'Updating dbo.Invoice Table'
GO

SET ANSI_NULLS, ANSI_PADDING, ANSI_WARNINGS, ARITHABORT, QUOTED_IDENTIFIER, CONCAT_NULL_YIELDS_NULL ON
GO

SET NUMERIC_ROUNDABORT OFF
GO


IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__InvoiceLi__Invoi__182C9B23')
      ALTER TABLE [dbo].[InvoiceLine] DROP CONSTRAINT [FK__InvoiceLi__Invoi__182C9B23]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__Invoice__Custome__164452B1')
      ALTER TABLE [dbo].[Invoice] DROP CONSTRAINT [FK__Invoice__Custome__164452B1]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   CREATE TABLE [dbo].[tmp_Invoice] (
   [InvoiceId] [int] NOT NULL,
   [CustomerId] [int] NULL,
   [InvoiceDate] [datetime] NULL,
   [BillingAddress] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL,
   [BillingCity] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL,
   [BillingState] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL,
   [BillingCountry] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL,
   [BillingPostalCode] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL,
   [Total] [numeric] (10, 2) NULL
)
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   INSERT INTO [dbo].[tmp_Invoice] ([InvoiceId], [CustomerId], [InvoiceDate], [BillingAddress], [BillingCity], [BillingState], [BillingCountry], [BillingPostalCode], [Total])
   SELECT [InvoiceId], [CustomerId], [InvoiceDate], [BillingAddress], [BillingCity], [BillingState], [BillingCountry], [BillingPostalCode], [Total]
   FROM [dbo].[Invoice]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   DROP TABLE [dbo].[Invoice]
GO

sp_rename N'[dbo].[tmp_Invoice]', N'Invoice'

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   ALTER TABLE [dbo].[Invoice] ADD CONSTRAINT [PK__Invoice__7C8480AE] PRIMARY KEY CLUSTERED ([InvoiceId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
BEGIN
   PRINT 'dbo.Invoice Table Updated Successfully'
   COMMIT TRANSACTION
END ELSE
BEGIN
   PRINT 'Failed To Update dbo.Invoice Table'
END
GO


--
-- Script To Update dbo.MediaType Table In .\sqlexpress.Chinook_ORIGINAL
-- Generated jueves, julio 23, 2009, at 05:28 PM
--
-- Please backup .\sqlexpress.Chinook_ORIGINAL before executing this script
--


BEGIN TRANSACTION
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

PRINT 'Updating dbo.MediaType Table'
GO

SET ANSI_NULLS, ANSI_PADDING, ANSI_WARNINGS, ARITHABORT, QUOTED_IDENTIFIER, CONCAT_NULL_YIELDS_NULL ON
GO

SET NUMERIC_ROUNDABORT OFF
GO


IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__Track__MediaType__1273C1CD')
      ALTER TABLE [dbo].[Track] DROP CONSTRAINT [FK__Track__MediaType__1273C1CD]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   CREATE TABLE [dbo].[tmp_MediaType] (
   [MediaTypeId] [int] NOT NULL,
   [Name] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL
)
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   INSERT INTO [dbo].[tmp_MediaType] ([MediaTypeId], [Name])
   SELECT [MediaTypeId], [Name]
   FROM [dbo].[MediaType]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   DROP TABLE [dbo].[MediaType]
GO

sp_rename N'[dbo].[tmp_MediaType]', N'MediaType'

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   ALTER TABLE [dbo].[MediaType] ADD CONSTRAINT [PK__MediaType__0AD2A005] PRIMARY KEY CLUSTERED ([MediaTypeId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
BEGIN
   PRINT 'dbo.MediaType Table Updated Successfully'
   COMMIT TRANSACTION
END ELSE
BEGIN
   PRINT 'Failed To Update dbo.MediaType Table'
END
GO


--
-- Script To Update dbo.Track Table In .\sqlexpress.Chinook_ORIGINAL
-- Generated jueves, julio 23, 2009, at 05:28 PM
--
-- Please backup .\sqlexpress.Chinook_ORIGINAL before executing this script
--


BEGIN TRANSACTION
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

PRINT 'Updating dbo.Track Table'
GO

SET ANSI_NULLS, ANSI_PADDING, ANSI_WARNINGS, ARITHABORT, QUOTED_IDENTIFIER, CONCAT_NULL_YIELDS_NULL ON
GO

SET NUMERIC_ROUNDABORT OFF
GO


IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__InvoiceLi__Track__173876EA')
      ALTER TABLE [dbo].[InvoiceLine] DROP CONSTRAINT [FK__InvoiceLi__Track__173876EA]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__PlaylistT__Track__1920BF5C')
      ALTER TABLE [dbo].[PlaylistTrack] DROP CONSTRAINT [FK__PlaylistT__Track__1920BF5C]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__Track__AlbumId__117F9D94')
      ALTER TABLE [dbo].[Track] DROP CONSTRAINT [FK__Track__AlbumId__117F9D94]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__Track__GenreId__1367E606')
      ALTER TABLE [dbo].[Track] DROP CONSTRAINT [FK__Track__GenreId__1367E606]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__Track__MediaType__1273C1CD')
      ALTER TABLE [dbo].[Track] DROP CONSTRAINT [FK__Track__MediaType__1273C1CD]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   CREATE TABLE [dbo].[tmp_Track] (
   [TrackId] [int] NOT NULL,
   [Name] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL,
   [AlbumId] [int] NULL,
   [MediaTypeId] [int] NULL,
   [GenreId] [int] NULL,
   [Composer] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL,
   [Milliseconds] [int] NULL,
   [Bytes] [int] NULL,
   [UnitPrice] [numeric] (10, 2) NULL
)
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   INSERT INTO [dbo].[tmp_Track] ([TrackId], [Name], [AlbumId], [MediaTypeId], [GenreId], [Composer], [Milliseconds], [Bytes], [UnitPrice])
   SELECT [TrackId], [Name], [AlbumId], [MediaTypeId], [GenreId], [Composer], [Milliseconds], [Bytes], [UnitPrice]
   FROM [dbo].[Track]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   DROP TABLE [dbo].[Track]
GO

sp_rename N'[dbo].[tmp_Track]', N'Track'

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   ALTER TABLE [dbo].[Track] ADD CONSTRAINT [PK__Track__0EA330E9] PRIMARY KEY CLUSTERED ([TrackId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
BEGIN
   PRINT 'dbo.Track Table Updated Successfully'
   COMMIT TRANSACTION
END ELSE
BEGIN
   PRINT 'Failed To Update dbo.Track Table'
END
GO


--
-- Script To Update dbo.InvoiceLine Table In .\sqlexpress.Chinook_ORIGINAL
-- Generated jueves, julio 23, 2009, at 05:28 PM
--
-- Please backup .\sqlexpress.Chinook_ORIGINAL before executing this script
--


BEGIN TRANSACTION
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

PRINT 'Updating dbo.InvoiceLine Table'
GO

SET ANSI_NULLS, ANSI_PADDING, ANSI_WARNINGS, ARITHABORT, QUOTED_IDENTIFIER, CONCAT_NULL_YIELDS_NULL ON
GO

SET NUMERIC_ROUNDABORT OFF
GO


IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__InvoiceLi__Invoi__182C9B23')
      ALTER TABLE [dbo].[InvoiceLine] DROP CONSTRAINT [FK__InvoiceLi__Invoi__182C9B23]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__InvoiceLi__Track__173876EA')
      ALTER TABLE [dbo].[InvoiceLine] DROP CONSTRAINT [FK__InvoiceLi__Track__173876EA]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   CREATE TABLE [dbo].[tmp_InvoiceLine] (
   [InvoiceLineId] [int] NOT NULL,
   [InvoiceId] [int] NULL,
   [TrackId] [int] NULL,
   [Quantity] [int] NULL,
   [UnitPrice] [numeric] (10, 2) NULL
)
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   INSERT INTO [dbo].[tmp_InvoiceLine] ([InvoiceLineId], [InvoiceId], [TrackId], [Quantity], [UnitPrice])
   SELECT [InvoiceLineId], [InvoiceId], [TrackId], [Quantity], [UnitPrice]
   FROM [dbo].[InvoiceLine]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   DROP TABLE [dbo].[InvoiceLine]
GO

sp_rename N'[dbo].[tmp_InvoiceLine]', N'InvoiceLine'

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   ALTER TABLE [dbo].[InvoiceLine] ADD CONSTRAINT [PK__InvoiceLine__023D5A04] PRIMARY KEY CLUSTERED ([InvoiceLineId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
BEGIN
   PRINT 'dbo.InvoiceLine Table Updated Successfully'
   COMMIT TRANSACTION
END ELSE
BEGIN
   PRINT 'Failed To Update dbo.InvoiceLine Table'
END
GO


--
-- Script To Update dbo.Playlist Table In .\sqlexpress.Chinook_ORIGINAL
-- Generated jueves, julio 23, 2009, at 05:28 PM
--
-- Please backup .\sqlexpress.Chinook_ORIGINAL before executing this script
--


BEGIN TRANSACTION
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

PRINT 'Updating dbo.Playlist Table'
GO

SET ANSI_NULLS, ANSI_PADDING, ANSI_WARNINGS, ARITHABORT, QUOTED_IDENTIFIER, CONCAT_NULL_YIELDS_NULL ON
GO

SET NUMERIC_ROUNDABORT OFF
GO


IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__PlaylistT__Playl__1A14E395')
      ALTER TABLE [dbo].[PlaylistTrack] DROP CONSTRAINT [FK__PlaylistT__Playl__1A14E395]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   CREATE TABLE [dbo].[tmp_Playlist] (
   [PlaylistId] [int] NOT NULL,
   [Name] [nvarchar] (255) COLLATE Modern_Spanish_CI_AS NULL
)
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   INSERT INTO [dbo].[tmp_Playlist] ([PlaylistId], [Name])
   SELECT [PlaylistId], [Name]
   FROM [dbo].[Playlist]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   DROP TABLE [dbo].[Playlist]
GO

sp_rename N'[dbo].[tmp_Playlist]', N'Playlist'

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   ALTER TABLE [dbo].[Playlist] ADD CONSTRAINT [PK__Playlist__060DEAE8] PRIMARY KEY CLUSTERED ([PlaylistId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
BEGIN
   PRINT 'dbo.Playlist Table Updated Successfully'
   COMMIT TRANSACTION
END ELSE
BEGIN
   PRINT 'Failed To Update dbo.Playlist Table'
END
GO


--
-- Script To Update dbo.PlaylistTrack Table In .\sqlexpress.Chinook_ORIGINAL
-- Generated jueves, julio 23, 2009, at 05:28 PM
--
-- Please backup .\sqlexpress.Chinook_ORIGINAL before executing this script
--


BEGIN TRANSACTION
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

PRINT 'Updating dbo.PlaylistTrack Table'
GO

SET ANSI_NULLS, ANSI_PADDING, ANSI_WARNINGS, ARITHABORT, QUOTED_IDENTIFIER, CONCAT_NULL_YIELDS_NULL ON
GO

SET NUMERIC_ROUNDABORT OFF
GO


IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'PK__PlaylistTrack__0F975522')
      ALTER TABLE [dbo].[PlaylistTrack] DROP CONSTRAINT [PK__PlaylistTrack__0F975522]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysindexes WHERE name = N'IFK_Playlist_PlaylistTrack')
      DROP INDEX [IFK_Playlist_PlaylistTrack] ON [dbo].[PlaylistTrack]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysindexes WHERE name = N'IFK_Track_PlaylistTrack')
      DROP INDEX [IFK_Track_PlaylistTrack] ON [dbo].[PlaylistTrack]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysindexes WHERE name = N'IPK_PlaylistTrack')
      DROP INDEX [IPK_PlaylistTrack] ON [dbo].[PlaylistTrack]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__PlaylistT__Playl__1A14E395')
      ALTER TABLE [dbo].[PlaylistTrack] DROP CONSTRAINT [FK__PlaylistT__Playl__1A14E395]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__PlaylistT__Track__1920BF5C')
      ALTER TABLE [dbo].[PlaylistTrack] DROP CONSTRAINT [FK__PlaylistT__Track__1920BF5C]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
BEGIN
   PRINT 'dbo.PlaylistTrack Table Updated Successfully'
   COMMIT TRANSACTION
END ELSE
BEGIN
   PRINT 'Failed To Update dbo.PlaylistTrack Table'
END
GO


--
-- Script To Update dbo.Artist Table In .\sqlexpress.Chinook_ORIGINAL
-- Generated jueves, julio 23, 2009, at 05:28 PM
--
-- Please backup .\sqlexpress.Chinook_ORIGINAL before executing this script
--


BEGIN TRANSACTION
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

PRINT 'Updating dbo.Artist Table'
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF NOT EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__Album__ArtistId__108B795B')
      ALTER TABLE [dbo].[Album] ADD CONSTRAINT [FK__Album__ArtistId__108B795B] FOREIGN KEY ([ArtistId]) REFERENCES [dbo].[Artist] ([ArtistId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
BEGIN
   PRINT 'dbo.Artist Table Updated Successfully'
   COMMIT TRANSACTION
END ELSE
BEGIN
   PRINT 'Failed To Update dbo.Artist Table'
END
GO


--
-- Script To Update dbo.Album Table In .\sqlexpress.Chinook_ORIGINAL
-- Generated jueves, julio 23, 2009, at 05:28 PM
--
-- Please backup .\sqlexpress.Chinook_ORIGINAL before executing this script
--


BEGIN TRANSACTION
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

PRINT 'Updating dbo.Album Table'
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FKA0CE20AA71897002')
      ALTER TABLE [dbo].[Album] DROP CONSTRAINT [FKA0CE20AA71897002]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF NOT EXISTS (SELECT name FROM sysobjects WHERE name = N'FKA0CE20AA71897002')
      ALTER TABLE [dbo].[Album] ADD CONSTRAINT [FKA0CE20AA71897002] FOREIGN KEY ([ArtistId]) REFERENCES [dbo].[Artist] ([ArtistId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF NOT EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__Track__AlbumId__117F9D94')
      ALTER TABLE [dbo].[Track] ADD CONSTRAINT [FK__Track__AlbumId__117F9D94] FOREIGN KEY ([AlbumId]) REFERENCES [dbo].[Album] ([AlbumId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
BEGIN
   PRINT 'dbo.Album Table Updated Successfully'
   COMMIT TRANSACTION
END ELSE
BEGIN
   PRINT 'Failed To Update dbo.Album Table'
END
GO


--
-- Script To Update dbo.Employee Table In .\sqlexpress.Chinook_ORIGINAL
-- Generated jueves, julio 23, 2009, at 05:28 PM
--
-- Please backup .\sqlexpress.Chinook_ORIGINAL before executing this script
--


BEGIN TRANSACTION
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

PRINT 'Updating dbo.Employee Table'
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK20E4895F4F019B89')
      ALTER TABLE [dbo].[Employee] DROP CONSTRAINT [FK20E4895F4F019B89]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF NOT EXISTS (SELECT name FROM sysobjects WHERE name = N'FK20E4895F4F019B89')
      ALTER TABLE [dbo].[Employee] ADD CONSTRAINT [FK20E4895F4F019B89] FOREIGN KEY ([ReportsTo]) REFERENCES [dbo].[Employee] ([EmployeeId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF NOT EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__Customer__Suppor__15502E78')
      ALTER TABLE [dbo].[Customer] ADD CONSTRAINT [FK__Customer__Suppor__15502E78] FOREIGN KEY ([SupportRepId]) REFERENCES [dbo].[Employee] ([EmployeeId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF NOT EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__Employee__Report__145C0A3F')
      ALTER TABLE [dbo].[Employee] ADD CONSTRAINT [FK__Employee__Report__145C0A3F] FOREIGN KEY ([ReportsTo]) REFERENCES [dbo].[Employee] ([EmployeeId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
BEGIN
   PRINT 'dbo.Employee Table Updated Successfully'
   COMMIT TRANSACTION
END ELSE
BEGIN
   PRINT 'Failed To Update dbo.Employee Table'
END
GO


--
-- Script To Update dbo.Customer Table In .\sqlexpress.Chinook_ORIGINAL
-- Generated jueves, julio 23, 2009, at 05:28 PM
--
-- Please backup .\sqlexpress.Chinook_ORIGINAL before executing this script
--


BEGIN TRANSACTION
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

PRINT 'Updating dbo.Customer Table'
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FKFE9A39C09970892A')
      ALTER TABLE [dbo].[Customer] DROP CONSTRAINT [FKFE9A39C09970892A]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF NOT EXISTS (SELECT name FROM sysobjects WHERE name = N'FKFE9A39C09970892A')
      ALTER TABLE [dbo].[Customer] ADD CONSTRAINT [FKFE9A39C09970892A] FOREIGN KEY ([SupportRepId]) REFERENCES [dbo].[Employee] ([EmployeeId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF NOT EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__Invoice__Custome__164452B1')
      ALTER TABLE [dbo].[Invoice] ADD CONSTRAINT [FK__Invoice__Custome__164452B1] FOREIGN KEY ([CustomerId]) REFERENCES [dbo].[Customer] ([CustomerId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
BEGIN
   PRINT 'dbo.Customer Table Updated Successfully'
   COMMIT TRANSACTION
END ELSE
BEGIN
   PRINT 'Failed To Update dbo.Customer Table'
END
GO


--
-- Script To Update dbo.Genre Table In .\sqlexpress.Chinook_ORIGINAL
-- Generated jueves, julio 23, 2009, at 05:28 PM
--
-- Please backup .\sqlexpress.Chinook_ORIGINAL before executing this script
--


BEGIN TRANSACTION
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

PRINT 'Updating dbo.Genre Table'
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF NOT EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__Track__GenreId__1367E606')
      ALTER TABLE [dbo].[Track] ADD CONSTRAINT [FK__Track__GenreId__1367E606] FOREIGN KEY ([GenreId]) REFERENCES [dbo].[Genre] ([GenreId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
BEGIN
   PRINT 'dbo.Genre Table Updated Successfully'
   COMMIT TRANSACTION
END ELSE
BEGIN
   PRINT 'Failed To Update dbo.Genre Table'
END
GO


--
-- Script To Update dbo.Invoice Table In .\sqlexpress.Chinook_ORIGINAL
-- Generated jueves, julio 23, 2009, at 05:28 PM
--
-- Please backup .\sqlexpress.Chinook_ORIGINAL before executing this script
--


BEGIN TRANSACTION
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

PRINT 'Updating dbo.Invoice Table'
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FKDC6081720C5DAD6')
      ALTER TABLE [dbo].[Invoice] DROP CONSTRAINT [FKDC6081720C5DAD6]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF NOT EXISTS (SELECT name FROM sysobjects WHERE name = N'FKDC6081720C5DAD6')
      ALTER TABLE [dbo].[Invoice] ADD CONSTRAINT [FKDC6081720C5DAD6] FOREIGN KEY ([CustomerId]) REFERENCES [dbo].[Customer] ([CustomerId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF NOT EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__InvoiceLi__Invoi__182C9B23')
      ALTER TABLE [dbo].[InvoiceLine] ADD CONSTRAINT [FK__InvoiceLi__Invoi__182C9B23] FOREIGN KEY ([InvoiceId]) REFERENCES [dbo].[Invoice] ([InvoiceId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
BEGIN
   PRINT 'dbo.Invoice Table Updated Successfully'
   COMMIT TRANSACTION
END ELSE
BEGIN
   PRINT 'Failed To Update dbo.Invoice Table'
END
GO


--
-- Script To Update dbo.MediaType Table In .\sqlexpress.Chinook_ORIGINAL
-- Generated jueves, julio 23, 2009, at 05:28 PM
--
-- Please backup .\sqlexpress.Chinook_ORIGINAL before executing this script
--


BEGIN TRANSACTION
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

PRINT 'Updating dbo.MediaType Table'
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF NOT EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__Track__MediaType__1273C1CD')
      ALTER TABLE [dbo].[Track] ADD CONSTRAINT [FK__Track__MediaType__1273C1CD] FOREIGN KEY ([MediaTypeId]) REFERENCES [dbo].[MediaType] ([MediaTypeId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
BEGIN
   PRINT 'dbo.MediaType Table Updated Successfully'
   COMMIT TRANSACTION
END ELSE
BEGIN
   PRINT 'Failed To Update dbo.MediaType Table'
END
GO


--
-- Script To Update dbo.Track Table In .\sqlexpress.Chinook_ORIGINAL
-- Generated jueves, julio 23, 2009, at 05:28 PM
--
-- Please backup .\sqlexpress.Chinook_ORIGINAL before executing this script
--


BEGIN TRANSACTION
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

PRINT 'Updating dbo.Track Table'
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK5FEAAD4059AC03F0')
      ALTER TABLE [dbo].[Track] DROP CONSTRAINT [FK5FEAAD4059AC03F0]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF NOT EXISTS (SELECT name FROM sysobjects WHERE name = N'FK5FEAAD4059AC03F0')
      ALTER TABLE [dbo].[Track] ADD CONSTRAINT [FK5FEAAD4059AC03F0] FOREIGN KEY ([AlbumId]) REFERENCES [dbo].[Album] ([AlbumId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK5FEAAD406F31F4C0')
      ALTER TABLE [dbo].[Track] DROP CONSTRAINT [FK5FEAAD406F31F4C0]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF NOT EXISTS (SELECT name FROM sysobjects WHERE name = N'FK5FEAAD406F31F4C0')
      ALTER TABLE [dbo].[Track] ADD CONSTRAINT [FK5FEAAD406F31F4C0] FOREIGN KEY ([GenreId]) REFERENCES [dbo].[Genre] ([GenreId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK5FEAAD40CC29227D')
      ALTER TABLE [dbo].[Track] DROP CONSTRAINT [FK5FEAAD40CC29227D]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF NOT EXISTS (SELECT name FROM sysobjects WHERE name = N'FK5FEAAD40CC29227D')
      ALTER TABLE [dbo].[Track] ADD CONSTRAINT [FK5FEAAD40CC29227D] FOREIGN KEY ([MediaTypeId]) REFERENCES [dbo].[MediaType] ([MediaTypeId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF NOT EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__InvoiceLi__Track__173876EA')
      ALTER TABLE [dbo].[InvoiceLine] ADD CONSTRAINT [FK__InvoiceLi__Track__173876EA] FOREIGN KEY ([TrackId]) REFERENCES [dbo].[Track] ([TrackId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF NOT EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__PlaylistT__Track__1920BF5C')
      ALTER TABLE [dbo].[PlaylistTrack] ADD CONSTRAINT [FK__PlaylistT__Track__1920BF5C] FOREIGN KEY ([TrackId]) REFERENCES [dbo].[Track] ([TrackId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
BEGIN
   PRINT 'dbo.Track Table Updated Successfully'
   COMMIT TRANSACTION
END ELSE
BEGIN
   PRINT 'Failed To Update dbo.Track Table'
END
GO


--
-- Script To Update dbo.InvoiceLine Table In .\sqlexpress.Chinook_ORIGINAL
-- Generated jueves, julio 23, 2009, at 05:28 PM
--
-- Please backup .\sqlexpress.Chinook_ORIGINAL before executing this script
--


BEGIN TRANSACTION
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

PRINT 'Updating dbo.InvoiceLine Table'
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK64ABF9253AAD7382')
      ALTER TABLE [dbo].[InvoiceLine] DROP CONSTRAINT [FK64ABF9253AAD7382]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF NOT EXISTS (SELECT name FROM sysobjects WHERE name = N'FK64ABF9253AAD7382')
      ALTER TABLE [dbo].[InvoiceLine] ADD CONSTRAINT [FK64ABF9253AAD7382] FOREIGN KEY ([TrackId]) REFERENCES [dbo].[Track] ([TrackId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK64ABF9256A861DFE')
      ALTER TABLE [dbo].[InvoiceLine] DROP CONSTRAINT [FK64ABF9256A861DFE]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF NOT EXISTS (SELECT name FROM sysobjects WHERE name = N'FK64ABF9256A861DFE')
      ALTER TABLE [dbo].[InvoiceLine] ADD CONSTRAINT [FK64ABF9256A861DFE] FOREIGN KEY ([InvoiceId]) REFERENCES [dbo].[Invoice] ([InvoiceId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
BEGIN
   PRINT 'dbo.InvoiceLine Table Updated Successfully'
   COMMIT TRANSACTION
END ELSE
BEGIN
   PRINT 'Failed To Update dbo.InvoiceLine Table'
END
GO


--
-- Script To Update dbo.Playlist Table In .\sqlexpress.Chinook_ORIGINAL
-- Generated jueves, julio 23, 2009, at 05:28 PM
--
-- Please backup .\sqlexpress.Chinook_ORIGINAL before executing this script
--


BEGIN TRANSACTION
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

PRINT 'Updating dbo.Playlist Table'
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF NOT EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__PlaylistT__Playl__1A14E395')
      ALTER TABLE [dbo].[PlaylistTrack] ADD CONSTRAINT [FK__PlaylistT__Playl__1A14E395] FOREIGN KEY ([PlaylistId]) REFERENCES [dbo].[Playlist] ([PlaylistId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
BEGIN
   PRINT 'dbo.Playlist Table Updated Successfully'
   COMMIT TRANSACTION
END ELSE
BEGIN
   PRINT 'Failed To Update dbo.Playlist Table'
END
GO


--
-- Script To Update dbo.PlaylistTrack Table In .\sqlexpress.Chinook_ORIGINAL
-- Generated jueves, julio 23, 2009, at 05:28 PM
--
-- Please backup .\sqlexpress.Chinook_ORIGINAL before executing this script
--


BEGIN TRANSACTION
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

PRINT 'Updating dbo.PlaylistTrack Table'
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FKFDB1981B33DC0761')
      ALTER TABLE [dbo].[PlaylistTrack] DROP CONSTRAINT [FKFDB1981B33DC0761]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF NOT EXISTS (SELECT name FROM sysobjects WHERE name = N'FKFDB1981B33DC0761')
      ALTER TABLE [dbo].[PlaylistTrack] ADD CONSTRAINT [FKFDB1981B33DC0761] FOREIGN KEY ([PlaylistId]) REFERENCES [dbo].[Playlist] ([PlaylistId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FKFDB1981B3AAD7382')
      ALTER TABLE [dbo].[PlaylistTrack] DROP CONSTRAINT [FKFDB1981B3AAD7382]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF NOT EXISTS (SELECT name FROM sysobjects WHERE name = N'FKFDB1981B3AAD7382')
      ALTER TABLE [dbo].[PlaylistTrack] ADD CONSTRAINT [FKFDB1981B3AAD7382] FOREIGN KEY ([TrackId]) REFERENCES [dbo].[Track] ([TrackId])
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
BEGIN
   PRINT 'dbo.PlaylistTrack Table Updated Successfully'
   COMMIT TRANSACTION
END ELSE
BEGIN
   PRINT 'Failed To Update dbo.PlaylistTrack Table'
END
GO
