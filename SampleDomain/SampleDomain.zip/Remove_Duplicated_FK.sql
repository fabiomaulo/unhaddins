--
-- Script To Update dbo.Album Table In .\sqlexpress.Chinook_ORIGINAL
-- Generated jueves, julio 23, 2009, at 05:29 PM
--
-- Please backup .\sqlexpress.Chinook_ORIGINAL before executing this script
--


BEGIN TRANSACTION
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

PRINT 'Updating dbo.Album Table'
GO

SET ANSI_NULLS, ANSI_PADDING, ANSI_WARNINGS, ARITHABORT, QUOTED_IDENTIFIER, CONCAT_NULL_YIELDS_NULL ON
GO

SET NUMERIC_ROUNDABORT OFF
GO


IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__Album__ArtistId__108B795B')
      ALTER TABLE [dbo].[Album] DROP CONSTRAINT [FK__Album__ArtistId__108B795B]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
BEGIN
   PRINT 'dbo.Album Table Updated Successfully'
   COMMIT TRANSACTION
END ELSE
BEGIN
   PRINT 'Failed To Update dbo.Album Table'
END
GO

--
-- Script To Update dbo.Employee Table In .\sqlexpress.Chinook_ORIGINAL
-- Generated jueves, julio 23, 2009, at 05:29 PM
--
-- Please backup .\sqlexpress.Chinook_ORIGINAL before executing this script
--


BEGIN TRANSACTION
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

PRINT 'Updating dbo.Employee Table'
GO

SET ANSI_NULLS, ANSI_PADDING, ANSI_WARNINGS, ARITHABORT, QUOTED_IDENTIFIER, CONCAT_NULL_YIELDS_NULL ON
GO

SET NUMERIC_ROUNDABORT OFF
GO


IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__Employee__Report__145C0A3F')
      ALTER TABLE [dbo].[Employee] DROP CONSTRAINT [FK__Employee__Report__145C0A3F]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
BEGIN
   PRINT 'dbo.Employee Table Updated Successfully'
   COMMIT TRANSACTION
END ELSE
BEGIN
   PRINT 'Failed To Update dbo.Employee Table'
END
GO

--
-- Script To Update dbo.Customer Table In .\sqlexpress.Chinook_ORIGINAL
-- Generated jueves, julio 23, 2009, at 05:29 PM
--
-- Please backup .\sqlexpress.Chinook_ORIGINAL before executing this script
--


BEGIN TRANSACTION
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

PRINT 'Updating dbo.Customer Table'
GO

SET ANSI_NULLS, ANSI_PADDING, ANSI_WARNINGS, ARITHABORT, QUOTED_IDENTIFIER, CONCAT_NULL_YIELDS_NULL ON
GO

SET NUMERIC_ROUNDABORT OFF
GO


IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__Customer__Suppor__15502E78')
      ALTER TABLE [dbo].[Customer] DROP CONSTRAINT [FK__Customer__Suppor__15502E78]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
BEGIN
   PRINT 'dbo.Customer Table Updated Successfully'
   COMMIT TRANSACTION
END ELSE
BEGIN
   PRINT 'Failed To Update dbo.Customer Table'
END
GO

--
-- Script To Update dbo.Invoice Table In .\sqlexpress.Chinook_ORIGINAL
-- Generated jueves, julio 23, 2009, at 05:29 PM
--
-- Please backup .\sqlexpress.Chinook_ORIGINAL before executing this script
--


BEGIN TRANSACTION
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

PRINT 'Updating dbo.Invoice Table'
GO

SET ANSI_NULLS, ANSI_PADDING, ANSI_WARNINGS, ARITHABORT, QUOTED_IDENTIFIER, CONCAT_NULL_YIELDS_NULL ON
GO

SET NUMERIC_ROUNDABORT OFF
GO


IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__Invoice__Custome__164452B1')
      ALTER TABLE [dbo].[Invoice] DROP CONSTRAINT [FK__Invoice__Custome__164452B1]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
BEGIN
   PRINT 'dbo.Invoice Table Updated Successfully'
   COMMIT TRANSACTION
END ELSE
BEGIN
   PRINT 'Failed To Update dbo.Invoice Table'
END
GO

--
-- Script To Update dbo.Track Table In .\sqlexpress.Chinook_ORIGINAL
-- Generated jueves, julio 23, 2009, at 05:29 PM
--
-- Please backup .\sqlexpress.Chinook_ORIGINAL before executing this script
--


BEGIN TRANSACTION
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

PRINT 'Updating dbo.Track Table'
GO

SET ANSI_NULLS, ANSI_PADDING, ANSI_WARNINGS, ARITHABORT, QUOTED_IDENTIFIER, CONCAT_NULL_YIELDS_NULL ON
GO

SET NUMERIC_ROUNDABORT OFF
GO


IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__Track__AlbumId__117F9D94')
      ALTER TABLE [dbo].[Track] DROP CONSTRAINT [FK__Track__AlbumId__117F9D94]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__Track__GenreId__1367E606')
      ALTER TABLE [dbo].[Track] DROP CONSTRAINT [FK__Track__GenreId__1367E606]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__Track__MediaType__1273C1CD')
      ALTER TABLE [dbo].[Track] DROP CONSTRAINT [FK__Track__MediaType__1273C1CD]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
BEGIN
   PRINT 'dbo.Track Table Updated Successfully'
   COMMIT TRANSACTION
END ELSE
BEGIN
   PRINT 'Failed To Update dbo.Track Table'
END
GO

--
-- Script To Update dbo.InvoiceLine Table In .\sqlexpress.Chinook_ORIGINAL
-- Generated jueves, julio 23, 2009, at 05:29 PM
--
-- Please backup .\sqlexpress.Chinook_ORIGINAL before executing this script
--


BEGIN TRANSACTION
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

PRINT 'Updating dbo.InvoiceLine Table'
GO

SET ANSI_NULLS, ANSI_PADDING, ANSI_WARNINGS, ARITHABORT, QUOTED_IDENTIFIER, CONCAT_NULL_YIELDS_NULL ON
GO

SET NUMERIC_ROUNDABORT OFF
GO


IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__InvoiceLi__Invoi__182C9B23')
      ALTER TABLE [dbo].[InvoiceLine] DROP CONSTRAINT [FK__InvoiceLi__Invoi__182C9B23]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__InvoiceLi__Track__173876EA')
      ALTER TABLE [dbo].[InvoiceLine] DROP CONSTRAINT [FK__InvoiceLi__Track__173876EA]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
BEGIN
   PRINT 'dbo.InvoiceLine Table Updated Successfully'
   COMMIT TRANSACTION
END ELSE
BEGIN
   PRINT 'Failed To Update dbo.InvoiceLine Table'
END
GO

--
-- Script To Update dbo.PlaylistTrack Table In .\sqlexpress.Chinook_ORIGINAL
-- Generated jueves, julio 23, 2009, at 05:29 PM
--
-- Please backup .\sqlexpress.Chinook_ORIGINAL before executing this script
--


BEGIN TRANSACTION
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

PRINT 'Updating dbo.PlaylistTrack Table'
GO

SET ANSI_NULLS, ANSI_PADDING, ANSI_WARNINGS, ARITHABORT, QUOTED_IDENTIFIER, CONCAT_NULL_YIELDS_NULL ON
GO

SET NUMERIC_ROUNDABORT OFF
GO


IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__PlaylistT__Playl__1A14E395')
      ALTER TABLE [dbo].[PlaylistTrack] DROP CONSTRAINT [FK__PlaylistT__Playl__1A14E395]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
   IF EXISTS (SELECT name FROM sysobjects WHERE name = N'FK__PlaylistT__Track__1920BF5C')
      ALTER TABLE [dbo].[PlaylistTrack] DROP CONSTRAINT [FK__PlaylistT__Track__1920BF5C]
GO

IF @@ERROR <> 0
   IF @@TRANCOUNT = 1 ROLLBACK TRANSACTION
GO

IF @@TRANCOUNT = 1
BEGIN
   PRINT 'dbo.PlaylistTrack Table Updated Successfully'
   COMMIT TRANSACTION
END ELSE
BEGIN
   PRINT 'Failed To Update dbo.PlaylistTrack Table'
END
GO